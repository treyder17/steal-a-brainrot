# 🧠 Steal a Brainrot - Multiplayer

## Lokales Testen

```bash
npm install
npm start
# Öffne: http://localhost:3000
```

## 🚀 Auf Railway.app deployen (KOSTENLOS)

### Schritt 1 - GitHub Repo
1. Gehe zu github.com → "New repository"
2. Name: `steal-a-brainrot`
3. Lade diese Dateien hoch:
   - `server.js`
   - `package.json`
   - `railway.toml`
   - Ordner `public/` mit `index.html`

### Schritt 2 - Railway
1. Gehe zu **railway.app**
2. Klicke "Start a New Project"
3. Wähle "Deploy from GitHub repo"
4. Wähle dein `steal-a-brainrot` Repo
5. Railway deployed automatisch! 🎉

### Schritt 3 - Domain
1. In Railway: "Settings" → "Domains"
2. Klicke "Generate Domain"
3. Du bekommst eine URL wie: `steal-a-brainrot.up.railway.app`
4. Diese URL auf **Playhop** einreichen!

## 📁 Dateistruktur
```
brainrot-game/
├── server.js          ← Node.js + Socket.io Server
├── package.json       ← Dependencies
├── railway.toml       ← Deployment Config
└── public/
    └── index.html     ← Das komplette Spiel (mit 3D Modellen)
```

## 🎮 Steuerung
- **WASD** - Bewegen
- **Maus ziehen** - Kamera drehen
- **Scroll** - Zoom
- **E / Leertaste** - Stehlen (wenn du nah an einer Gegner-Basis bist)
- **Förderband** (unten) - Brainrots kaufen

## ⚙️ Server Features
- Echtzeit-Multiplayer mit Socket.io
- Server-seitige Validierung (kein Cheaten!)
- Passives Einkommen alle 1 Sekunde
- Basis-Schutz (8 Sekunden nach Diebstahl)
- Speed-Penalty beim Stehlen (4 Sekunden)
- 3 Sekunden Steal-Cooldown
- AFK-Kick nach 60 Sekunden
- Förderband refresht alle 30 Sekunden
